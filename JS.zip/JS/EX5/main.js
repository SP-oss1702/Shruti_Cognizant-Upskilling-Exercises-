/* ===================================
   Event Constructor Function
   =================================== */

function Event(name, date, seats) {

    this.name = name;
    this.date = date;
    this.seats = seats;
}


/* ===================================
   Prototype Method
   =================================== */

Event.prototype.checkAvailability =
function() {

    if (this.seats > 0) {

        return "Seats Available";
    }
    else {

        return "Event Full";
    }
};


/* ===================================
   Create Event Objects
   =================================== */

const event1 =
    new Event(
        "Tree Plantation Drive",
        "15 June 2026",
        25
    );

const event2 =
    new Event(
        "Blood Donation Camp",
        "20 June 2026",
        0
    );


/* ===================================
   Display Event Details
   =================================== */

const output =
    document.getElementById("output");

[event1, event2].forEach(event => {

    let entries =
        Object.entries(event);

    let details = "";

    entries.forEach(([key, value]) => {

        details += `
            <strong>${key}</strong> :
            ${value}<br>
        `;
    });

    output.innerHTML += `
        <div class="eventCard">

            ${details}

            <strong>Status:</strong>
            ${event.checkAvailability()}

        </div>
    `;
});


/* ===================================
   Console Output
   =================================== */

console.log(
    Object.entries(event1)
);