/*Mock API Endpoint*/
const API_URL =
"https://jsonplaceholder.typicode.com/users";



/*using .then() and .catch()*/
const API_URL =
"https://jsonplaceholder.typicode.com/users";

const container =
document.getElementById("eventContainer");

const spinner =
document.getElementById("spinner");


function displayEvents(data) {

    container.innerHTML = "";

    data.forEach(item => {

        container.innerHTML += `
            <div class="eventCard">
                <h3>${item.name}</h3>
                <p>Email: ${item.email}</p>
            </div>
        `;
    });
}


/* ===================================
   Using .then() and .catch()
   =================================== */

function loadEventsThen() {

    spinner.style.display = "block";

    fetch(API_URL)

        .then(response => {

            if (!response.ok) {

                throw new Error(
                    "Failed to fetch data"
                );
            }

            return response.json();
        })

        .then(data => {

            displayEvents(data);
        })

        .catch(error => {

            alert(
                "Error: " + error.message
            );

            console.error(error);
        })

        .finally(() => {

            spinner.style.display = "none";
        });
}

/* ===================================
   Using async / await
   =================================== */

async function loadEventsAsync() {

    spinner.style.display = "block";

    try {

        const response =
            await fetch(API_URL);

        if (!response.ok) {

            throw new Error(
                "Failed to fetch data"
            );
        }

        const data =
            await response.json();

        displayEvents(data);
    }

    catch(error) {

        alert(
            "Error: " + error.message
        );

        console.error(error);
    }

    finally {

        spinner.style.display = "none";
    }
}