/* ===================================
   Form Reference
   =================================== */

const form =
    document.getElementById(
        "registrationForm"
    );


/* ===================================
   Form Submit Event
   =================================== */

form.addEventListener(
    "submit",
    function(event) {

        /* Prevent Page Reload */

        event.preventDefault();

        /* Clear Previous Errors */

        document.getElementById(
            "nameError"
        ).textContent = "";

        document.getElementById(
            "emailError"
        ).textContent = "";

        document.getElementById(
            "eventError"
        ).textContent = "";

        document.getElementById(
            "successMessage"
        ).textContent = "";

        /* Access Form Elements */

        const name =
            form.elements["name"].value.trim();

        const email =
            form.elements["email"].value.trim();

        const selectedEvent =
            form.elements["event"].value;

        let isValid = true;

        /* Validate Name */

        if (name === "") {

            document.getElementById(
                "nameError"
            ).textContent =
            "Name is required";

            isValid = false;
        }

        /* Validate Email */

        if (email === "") {

            document.getElementById(
                "emailError"
            ).textContent =
            "Email is required";

            isValid = false;
        }

        /* Validate Event */

        if (selectedEvent === "") {

            document.getElementById(
                "eventError"
            ).textContent =
            "Please select an event";

            isValid = false;
        }

        /* Success Message */

        if (isValid) {

            document.getElementById(
                "successMessage"
            ).textContent =
            `✅ Registration successful for ${selectedEvent}`;
        }
    }
);