$(document).ready(function () {

    /* ==============================
       Click Event
       ============================== */

    $('#registerBtn').click(function () {

        alert("✅ Registration Successful!");

        $('.eventCard').fadeIn(1000);
    });

    /* ==============================
       Fade Out Event Card
       ============================== */

    $('#hideBtn').click(function () {

        $('.eventCard').fadeOut(1000);
    });

});