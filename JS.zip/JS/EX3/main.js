// Event Data
const events = [

    {
        name: "Tree Plantation Drive",
        date: "2026-07-15",
        seats: 10
    },

    {
        name: "Blood Donation Camp",
        date: "2025-01-10",
        seats: 20
    },

    {
        name: "Community Cleanup",
        date: "2026-08-20",
        seats: 0
    },

    {
        name: "Cultural Festival",
        date: "2026-09-05",
        seats: 25
    }
];

const today = new Date();

const container =
    document.getElementById("eventContainer");

/* Loop through events */
events.forEach(function(event) {

    let eventDate =
        new Date(event.date);

    /* Condition: show only upcoming events with seats */

    if (eventDate > today && event.seats > 0) {

        container.innerHTML += `
            <div class="eventCard">
                <h3>${event.name}</h3>
                <p>Date: ${event.date}</p>
                <p>Available Seats: ${event.seats}</p>

                <button onclick="register('${event.name}')">
                    Register
                </button>
            </div>
        `;
    }
    else {

        console.log(
            `${event.name} is hidden (past event or full)`
        );
    }
});


/* Registration Function */

function register(eventName) {

    try {

        if (!eventName) {
            throw new Error(
                "Invalid event selected."
            );
        }

        alert(
            `Registration successful for ${eventName}`
        );

    }
    catch(error) {

        console.error(
            "Registration Error:",
            error.message
        );

        alert(
            "Error: " + error.message
        );
    }
}