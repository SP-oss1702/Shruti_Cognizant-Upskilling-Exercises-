// Constants (cannot be changed)
const eventName = "Tree Plantation Drive";
const eventDate = "15 June 2026";

// Variable (can be changed)
let availableSeats = 50;

// Display event information using template literals
document.getElementById("eventInfo").innerHTML =
    `Event: ${eventName} <br>
     Date: ${eventDate} <br>
     Available Seats: ${availableSeats}`;

// Registration Function
function registerUser() {

    if (availableSeats > 0) {

        availableSeats--;   // Decrease seat count

        document.getElementById("seatInfo").innerHTML =
            `✅ Registration Successful! Remaining Seats: ${availableSeats}`;

        console.log(`Remaining Seats: ${availableSeats}`);
    }
    else {

        document.getElementById("seatInfo").innerHTML =
            "❌ No seats available.";

        console.log("No seats available.");
    }
}