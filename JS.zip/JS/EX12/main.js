/* ===================================
   Form Reference
   =================================== */

const form =
    document.getElementById(
        "registrationForm"
    );

const message =
    document.getElementById(
        "message"
    );

const loading =
    document.getElementById(
        "loading"
    );


/* ===================================
   Submit Form
   =================================== */

form.addEventListener(
    "submit",
    function(event) {

        event.preventDefault();

        const userData = {

            name:
                document.getElementById(
                    "name"
                ).value,

            email:
                document.getElementById(
                    "email"
                ).value,

            event:
                document.getElementById(
                    "event"
                ).value
        };

        loading.style.display = "block";
        message.textContent = "";

        /* Simulate delayed response */

        setTimeout(() => {

            fetch(
                "https://jsonplaceholder.typicode.com/posts",
                {
                    method: "POST",

                    headers: {
                        "Content-Type":
                        "application/json"
                    },

                    body:
                    JSON.stringify(
                        userData
                    )
                }
            )

            .then(response => {

                if (!response.ok) {

                    throw new Error(
                        "Registration Failed"
                    );
                }

                return response.json();
            })

            .then(data => {

                loading.style.display =
                    "none";

                message.style.color =
                    "green";

                message.textContent =
                    "✅ Registration Successful!";
            })

            .catch(error => {

                loading.style.display =
                    "none";

                message.style.color =
                    "red";

                message.textContent =
                    "❌ " +
                    error.message;
            });

        }, 2000); // 2-second delay

    }
);