/* ===================================
   Event Data
   =================================== */

const events = [

    {
        name: "Tree Plantation Drive",
        category: "Environment"
    },

    {
        name: "Blood Donation Camp",
        category: "Health"
    },

    {
        name: "Cultural Festival",
        category: "Culture"
    },

    {
        name: "Community Cleanup",
        category: "Environment"
    }
];


/* ===================================
   DOM Elements
   =================================== */

const container =
    document.getElementById("eventContainer");


/* ===================================
   Display Events
   =================================== */

function displayEvents(eventList) {

    container.innerHTML = "";

    eventList.forEach(event => {

        const card =
            document.createElement("div");

        card.className = "eventCard";

        card.innerHTML = `
            <h3>${event.name}</h3>
            <p>Category: ${event.category}</p>

            <button onclick="registerEvent('${event.name}')">
                Register
            </button>
        `;

        container.appendChild(card);
    });
}


/* ===================================
   onclick Event
   Register Button
   =================================== */

function registerEvent(eventName) {

    alert(
        `✅ Registered for ${eventName}`
    );
}


/* ===================================
   onchange Event
   Category Filter
   =================================== */

function filterEvents() {

    const selectedCategory =
        document.getElementById(
            "categoryFilter"
        ).value;

    if (selectedCategory === "All") {

        displayEvents(events);

        return;
    }

    const filteredEvents =
        events.filter(
            event =>
            event.category === selectedCategory
        );

    displayEvents(filteredEvents);
}


/* ===================================
   keydown Event
   Search Event
   =================================== */

function searchEvents() {

    setTimeout(() => {

        const searchText =
            document.getElementById(
                "searchBox"
            ).value.toLowerCase();

        const filteredEvents =
            events.filter(
                event =>
                event.name
                .toLowerCase()
                .includes(searchText)
            );

        displayEvents(filteredEvents);

    }, 0);
}


/* ===================================
   Initial Display
   =================================== */

displayEvents(events);