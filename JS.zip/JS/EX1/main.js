// Display message in browser console
console.log("Welcome to the Community Portal");

// Alert when page is fully loaded
window.onload = function () {

    alert("Community Portal page loaded successfully!");

};