/* ===================================
   Event Array
   =================================== */

let events = [

    {
        title: "Guitar Workshop",
        category: "Music"
    },

    {
        title: "Baking Workshop",
        category: "Cooking"
    },

    {
        title: "Singing Competition",
        category: "Music"
    }
];


/* ===================================
   Add New Events using push()
   =================================== */

events.push({
    title: "Piano Concert",
    category: "Music"
});

events.push({
    title: "Art Exhibition",
    category: "Art"
});


/* ===================================
   Filter Only Music Events
   =================================== */

let musicEvents = events.filter(
    event => event.category === "Music"
);


/* ===================================
   Format Display Cards using map()
   =================================== */

let eventCards = musicEvents.map(
    event => `
        <div class="eventCard">
            <h3>${event.title}</h3>
            <p>
                Workshop on ${event.title}
            </p>
            <p>
                Category: ${event.category}
            </p>
        </div>
    `
);


/* ===================================
   Display on Web Page
   =================================== */

document.getElementById(
    "eventContainer"
).innerHTML = eventCards.join("");


/* ===================================
   Console Output
   =================================== */

console.log(events);
console.log(musicEvents);