/* ===================================
   Event Array
   =================================== */

let events = [];


/* ===================================
   addEvent()
   Adds a new event
   =================================== */

function addEvent(name, category, seats) {

    events.push({
        name: name,
        category: category,
        seats: seats
    });
}


/* ===================================
   registerUser()
   Registers a user
   =================================== */

function registerUser(eventName) {

    let event = events.find(
        e => e.name === eventName
    );

    if (event && event.seats > 0) {

        event.seats--;

        console.log(
            `Registered for ${eventName}`
        );
    }
    else {

        console.log(
            `No seats available for ${eventName}`
        );
    }
}


/* ===================================
   Closure Example
   Track registrations by category
   =================================== */

function registrationTracker(category) {

    let totalRegistrations = 0;

    return function() {

        totalRegistrations++;

        console.log(
            `${category} Registrations: ${totalRegistrations}`
        );

        return totalRegistrations;
    };
}


/* ===================================
   Create Closure Objects
   =================================== */

const sportsTracker =
    registrationTracker("Sports");

const culturalTracker =
    registrationTracker("Cultural");


/* ===================================
   Higher-Order Function
   Accepts Callback
   =================================== */

function filterEventsByCategory(
    category,
    callback
) {

    let filteredEvents =
        events.filter(
            event =>
            event.category === category
        );

    callback(filteredEvents);
}


/* ===================================
   Callback Function
   =================================== */

function displayEvents(filteredEvents) {

    const container =
        document.getElementById(
            "eventContainer"
        );

    container.innerHTML = "";

    filteredEvents.forEach(event => {

        container.innerHTML += `
            <div class="eventCard">
                <h3>${event.name}</h3>
                <p>Category: ${event.category}</p>
                <p>Seats: ${event.seats}</p>
            </div>
        `;
    });
}


/* ===================================
   Add Sample Events
   =================================== */

addEvent(
    "Football Tournament",
    "Sports",
    20
);

addEvent(
    "Cricket Match",
    "Sports",
    15
);

addEvent(
    "Cultural Festival",
    "Cultural",
    30
);

addEvent(
    "Dance Competition",
    "Cultural",
    25
);


/* ===================================
   Register Users
   =================================== */

registerUser(
    "Football Tournament"
);

sportsTracker();
sportsTracker();

culturalTracker();


/* ===================================
   Filter Events
   =================================== */

filterEventsByCategory(
    "Sports",
    displayEvents
);