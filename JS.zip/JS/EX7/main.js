/* ===================================
   Event Data
   =================================== */

const events = [
    {
        name: "Tree Plantation Drive",
        seats: 10
    },
    {
        name: "Blood Donation Camp",
        seats: 5
    },
    {
        name: "Cultural Festival",
        seats: 20
    }
];


/* ===================================
   Access DOM Element
   querySelector()
   =================================== */

const container =
    document.querySelector("#eventContainer");


/* ===================================
   Render Events
   =================================== */

function displayEvents() {

    container.innerHTML = "";

    events.forEach((event, index) => {

        /* Create Card */
        const card =
            document.createElement("div");

        card.className = "eventCard";

        card.innerHTML = `
            <h3>${event.name}</h3>
            <p>
                Available Seats:
                <span id="seat-${index}">
                    ${event.seats}
                </span>
            </p>
        `;

        /* Register Button */
        const registerBtn =
            document.createElement("button");

        registerBtn.textContent =
            "Register";

        registerBtn.className =
            "register";

        registerBtn.onclick =
            function() {

                registerUser(index);
            };

        /* Cancel Button */
        const cancelBtn =
            document.createElement("button");

        cancelBtn.textContent =
            "Cancel";

        cancelBtn.className =
            "cancel";

        cancelBtn.onclick =
            function() {

                cancelRegistration(index);
            };

        /* Append Buttons */
        card.appendChild(registerBtn);
        card.appendChild(cancelBtn);

        /* Append Card */
        container.appendChild(card);
    });
}


/* ===================================
   Register User
   =================================== */

function registerUser(index) {

    if (events[index].seats > 0) {

        events[index].seats--;

        displayEvents();
    }
    else {

        alert("No seats available!");
    }
}


/* ===================================
   Cancel Registration
   =================================== */

function cancelRegistration(index) {

    events[index].seats++;

    displayEvents();
}


/* ===================================
   Initial Render
   =================================== */

displayEvents();