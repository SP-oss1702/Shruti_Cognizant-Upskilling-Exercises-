/* ===================================
   Event List using const
   =================================== */

const events = [

    {
        name: "Tree Plantation Drive",
        category: "Environment",
        seats: 20
    },

    {
        name: "Music Festival",
        category: "Music",
        seats: 50
    },

    {
        name: "Blood Donation Camp",
        category: "Health",
        seats: 30
    }
];


/* ===================================
   Function with Default Parameter
   =================================== */

function addEvent(
    name = "New Event",
    category = "General",
    seats = 10
) {

    events.push({
        name,
        category,
        seats
    });
}


/* ===================================
   Add New Event
   =================================== */

addEvent(
    "Cooking Workshop",
    "Education",
    25
);


/* ===================================
   Spread Operator
   Clone Event List
   =================================== */

const clonedEvents = [...events];


/* ===================================
   Filter Music Events
   =================================== */

const musicEvents =
    clonedEvents.filter(
        event =>
        event.category === "Music"
    );


/* ===================================
   Display Events
   Using Destructuring
   =================================== */

const container =
    document.getElementById(
        "eventContainer"
    );

musicEvents.forEach(event => {

    /* Destructuring */

    const {
        name,
        category,
        seats
    } = event;

    container.innerHTML += `
        <div class="eventCard">

            <h3>${name}</h3>

            <p>
                Category: ${category}
            </p>

            <p>
                Seats: ${seats}
            </p>

        </div>
    `;
});


/* ===================================
   Console Output
   =================================== */

console.log(events);
console.log(clonedEvents);
console.log(musicEvents);